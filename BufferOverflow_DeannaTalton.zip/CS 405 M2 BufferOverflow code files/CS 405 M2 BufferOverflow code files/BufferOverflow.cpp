// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>       // Added for dynamically sized, bounds-safe user input

/*
 * Safely reads and validates user input.
 *
 * Returning a Boolean value notifies the calling function whether the input
 * was accepted. The std::string type manages its own memory and prevents the
 * user from writing beyond a fixed-size character buffer.
 */
bool get_validated_input(std::string& user_input,
    const std::size_t maximum_length)
{
    std::cout << "Enter a value: ";

    // Read the complete line so its total length can be validated.
    if (!std::getline(std::cin, user_input))
    {
        std::cout << "Input error: The value could not be read." << std::endl;
        return false;
    }

    // Reject input that exceeds the application's documented limit.
    if (user_input.length() > maximum_length)
    {
        std::cout << "BUFFER OVERFLOW PREVENTED: Input exceeded "
            << maximum_length << " characters." << std::endl;

        // Remove the rejected data so it cannot be used accidentally.
        user_input.clear();
        return false;
    }

    return true;
}

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    /*
     * The account number remains separate from user-controlled input.
     * A std::string replaces the fixed-size character array so input cannot
     * overwrite adjacent memory.
     */
    const std::string account_number = "CharlieBrown42";
    std::string user_input;

    // Define the business-rule limit in one clearly named constant.
    constexpr std::size_t maximum_input_length = 20;

    /*
     * Check the Boolean result returned by get_validated_input().
     * Invalid input is rejected before the program attempts to use it.
     */
    const bool input_accepted =
        get_validated_input(user_input, maximum_input_length);

    if (input_accepted)
    {
        std::cout << "You entered: " << user_input << std::endl;
        std::cout << "Input status: Accepted" << std::endl;
    }
    else
    {
        std::cout << "Input status: Rejected" << std::endl;
    }

    // Display the account number to prove that rejected input did not alter it.
    std::cout << "Account Number = " << account_number << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
