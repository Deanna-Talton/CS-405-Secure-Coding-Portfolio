// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <exception>
#include <iostream>
#include <stdexcept>

// Custom exception type for application-specific failures.
// Deriving from std::exception allows it to use the standard what() interface.
class CustomApplicationException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "A custom application error occurred.";
    }
};

bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Simulate a failure by throwing an exception from the C++ standard library.
    throw std::runtime_error(
        "Even More Custom Application Logic encountered an error.");
}
void do_custom_application_logic()
{
    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& exception)
    {
        // Display the standard exception message and continue processing.
        std::cout << "Standard exception caught: "
            << exception.what() << std::endl;
    }

    std::cout << "Leaving Custom Application Logic." << std::endl;

    // Throw the application-specific exception so main can catch it explicitly.
    throw CustomApplicationException();

}

float divide(float num, float den)
{
    // Reject a zero denominator before performing the calculation.
    if (den == 0.0f)
    {
        throw std::invalid_argument("Division by zero is not permitted.");
    }

    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0.0f;

    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << "," << denominator
            << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& exception)
    {
        // Catch only the exception type thrown by divide().
        std::cout << "Division exception caught: "
            << exception.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomApplicationException& exception)
    {
        // Catch the custom type before the more general std::exception type.
        std::cout << "Custom exception caught: "
            << exception.what() << std::endl;
    }
    catch (const std::exception& exception)
    {
        // Handle any remaining exceptions derived from std::exception.
        std::cout << "Standard exception caught in main: "
            << exception.what() << std::endl;
    }
    catch (...)
    {
        // Provide a final safeguard for an exception of an unknown type.
        std::cout << "An unknown exception was caught." << std::endl;
    }

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu