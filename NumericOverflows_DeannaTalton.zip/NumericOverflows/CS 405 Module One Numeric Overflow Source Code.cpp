// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits

/// <summary>
/// Safely performs repeated addition while preventing numeric overflow
/// or underflow for the numeric type represented by T.
/// </summary>
/// <typeparam name="T">The numeric data type used in the calculation</typeparam>
/// <param name="start">The initial value</param>
/// <param name="increment">The value added during each iteration</param>
/// <param name="steps">The number of additions to perform</param>
/// <param name="result">
/// Receives the calculated value or the last safe value if the operation fails
/// </param>
/// <returns>
/// True when every addition succeeds; false when an addition would exceed
/// the numeric limits of T
/// </returns>
template <typename T>
bool add_numbers(
    T const& start,
    T const& increment,
    unsigned long int const& steps,
    T& result)
{
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check the upper boundary before adding a positive increment.
        // Rearranging result + increment > max as result > max - increment
        // prevents the unsafe addition from occurring during the check.
        const bool would_overflow =
            increment > 0 &&
            result > std::numeric_limits<T>::max() - increment;

        // A negative increment acts like subtraction, so also protect the
        // lower boundary. lowest() represents the smallest value for T.
        const bool would_underflow =
            increment < 0 &&
            result < std::numeric_limits<T>::lowest() - increment;

        if (would_overflow || would_underflow)
        {
            // Return failure before executing an operation outside T's range.
            return false;
        }

        result += increment;
    }

    return true;
}

/// <summary>
/// Safely performs repeated subtraction while preventing numeric underflow
/// or overflow for the numeric type represented by T.
/// </summary>
/// <typeparam name="T">The numeric data type used in the calculation</typeparam>
/// <param name="start">The initial value</param>
/// <param name="decrement">The value subtracted during each iteration</param>
/// <param name="steps">The number of subtractions to perform</param>
/// <param name="result">
/// Receives the calculated value or the last safe value if the operation fails
/// </param>
/// <returns>
/// True when every subtraction succeeds; false when a subtraction would exceed
/// the numeric limits of T
/// </returns>
template <typename T>
bool subtract_numbers(
    T const& start,
    T const& decrement,
    unsigned long int const& steps,
    T& result)
{
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // SECURE CODING CHANGE:
        // Check the lower boundary before subtracting a positive decrement.
        // Rearranging result - decrement < lowest as
        // result < lowest + decrement prevents the unsafe subtraction.
        const bool would_underflow =
            decrement > 0 &&
            result < std::numeric_limits<T>::lowest() + decrement;

        // SECURE CODING CHANGE:
        // Subtracting a negative value acts like addition, so also protect
        // the upper boundary from overflow.
        const bool would_overflow =
            decrement < 0 &&
            result > std::numeric_limits<T>::max() + decrement;

        if (would_underflow || would_overflow)
        {
            // Return failure before executing an operation outside T's range.
            return false;
        }

        result -= decrement;
    }

    return true;
}


//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{
    // TODO: The add_numbers template function will overflow in the second method call
    //        You need to change the add_numbers method to:
    //        1. Detect when an overflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no overflow happened or
    //        4. Return something to tell test_overflow the addition failed
    //        NOTE: The add_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_overflow method to:
    //        1. Detect when an add_numbers failed
    //        2. Inform the user the overflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_overflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem. 
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    std::cout << "\tAdding Numbers Without Overflow ("
        << +start << ", " << +increment << ", " << steps << ") = ";

    // SECURE CODING CHANGE:
    // The result is passed by reference so add_numbers() can return both
    // the calculated value and a Boolean success or failure status.
    T result{};
    bool success = add_numbers<T>(start, increment, steps, result);

    // SECURE CODING CHANGE:
    // Only display the numeric result when the calculation succeeds.
    // A false status means the unsafe addition was prevented.
    if (success)
    {
        std::cout << +result
            << " | Success: " << std::boolalpha << success
            << std::endl;
    }
    else
    {
        std::cout << "Overflow detected and prevented"
            << " | Success: " << std::boolalpha << success
            << std::endl;
    }

    std::cout << "\tAdding Numbers With Overflow ("
        << +start << ", " << +increment << ", "
        << (steps + 1) << ") = ";

    // SECURE CODING CHANGE:
    // This call intentionally requests one additional step to verify that
    // add_numbers() detects and prevents an overflow before it occurs.
    success = add_numbers<T>(start, increment, steps + 1, result);

    // SECURE CODING CHANGE:
    // The calling function checks the returned status and clearly informs
    // the user when the operation cannot be completed safely.
    if (success)
    {
        std::cout << +result
            << " | Success: " << std::boolalpha << success
            << std::endl;
    }
    else
    {
        std::cout << "Overflow detected and prevented"
            << " | Success: " << std::boolalpha << success
            << std::endl;
    }
}

template <typename T>
void test_underflow()
{
    // TODO: The subtract_numbers template function will underflow in the second method call
    //        You need to change the subtract_numbers method to:
    //        1. Detect when an underflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no underflow happened or
    //        4. Return something to tell test_underflow the subtraction failed
    //        NOTE: The subtract_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_underflow method to:
    //        1. Detect when an subtract_numbers failed
    //        2. Inform the user the underflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_underflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem. 
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    std::cout << "\tSubtracting Numbers Without Underflow ("
        << +start << ", " << +decrement << ", " << steps << ") = ";

    // SECURE CODING CHANGE:
    // The result is passed by reference so subtract_numbers() can return
    // both the calculated value and a Boolean success or failure status.
    T result{};
    bool success = subtract_numbers<T>(start, decrement, steps, result);

    // SECURE CODING CHANGE:
    // Only display the numeric result when every subtraction succeeds.
    if (success)
    {
        std::cout << +result
            << " | Success: " << std::boolalpha << success
            << std::endl;
    }
    else
    {
        std::cout << "Underflow detected and prevented"
            << " | Success: " << std::boolalpha << success
            << std::endl;
    }

    // SECURE CODING CHANGE:
    // Six iterations only underflow unsigned types. Eleven iterations are
    // required to move from the maximum value past the lowest value for
    // signed integers and floating-point types as well.
    const unsigned long int underflow_steps = (steps * 2) + 1;

    std::cout << "\tSubtracting Numbers With Underflow ("
        << +start << ", " << +decrement << ", "
        << underflow_steps << ") = ";

    success =
        subtract_numbers<T>(start, decrement, underflow_steps, result);

    // SECURE CODING CHANGE:
    // A false status confirms that the function stopped before performing
    // a subtraction outside the range supported by the selected type.
    if (success)
    {
        std::cout << +result
            << " | Success: " << std::boolalpha << success
            << std::endl;
    }
    else
    {
        std::cout << "Underflow detected and prevented"
            << " | Success: " << std::boolalpha << success
            << std::endl;
    }
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    // CODE QUALITY CHANGE:
    // Corrected the console heading from "Undeflow" to "Underflow"
    // so the output accurately identifies the tests being performed.
    std::cout << "*** Running Underflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
