// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        // Convert time_t explicitly because srand() requires an unsigned int.
        srand(static_cast<unsigned int>(time(nullptr)));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, DISABLED_AlwaysFail)
{
    // This demonstration test remains disabled so the completed suite can pass.
    FAIL();
}

// Verify that one value can be added to a newly created vector.
TEST_F(CollectionTest, CanAddSingleValueToEmptyVector)
{
    // The vector must begin empty for this test to be meaningful.
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0U);

    add_entries(1);

    // Both conditions explicitly prove that one element was added.
    EXPECT_FALSE(collection->empty());
    EXPECT_EQ(collection->size(), 1U);
}

// Verify that five values can be added to a newly created vector.
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // Confirm the fixture supplied an empty vector before adding values.
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0U);

    add_entries(5);

    // Prove that the operation added exactly five elements.
    EXPECT_FALSE(collection->empty());
    EXPECT_EQ(collection->size(), 5U);
}

// Verify that max_size() can accommodate the current number of elements.
TEST_F(CollectionTest, MaxSizeIsGreaterThanOrEqualToCurrentSize)
{
    // Check the relationship when the vector contains zero elements.
    EXPECT_GE(collection->max_size(), collection->size());

    add_entries(1);
    EXPECT_EQ(collection->size(), 1U);
    EXPECT_GE(collection->max_size(), collection->size());

    // Add four more elements to reach a total size of five.
    add_entries(4);
    EXPECT_EQ(collection->size(), 5U);
    EXPECT_GE(collection->max_size(), collection->size());

    // Add five more elements to reach a total size of ten.
    add_entries(5);
    EXPECT_EQ(collection->size(), 10U);
    EXPECT_GE(collection->max_size(), collection->size());
}

// Verify that capacity() is never smaller than the vector's current size.
TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualToCurrentSize)
{
    // A newly created vector must have enough capacity for its current size.
    EXPECT_GE(collection->capacity(), collection->size());

    add_entries(1);
    EXPECT_EQ(collection->size(), 1U);
    EXPECT_GE(collection->capacity(), collection->size());

    // Add four more elements to reach a total size of five.
    add_entries(4);
    EXPECT_EQ(collection->size(), 5U);
    EXPECT_GE(collection->capacity(), collection->size());

    // Add five more elements to reach a total size of ten.
    add_entries(5);
    EXPECT_EQ(collection->size(), 10U);
    EXPECT_GE(collection->capacity(), collection->size());
}

// Verify that resize() can increase the number of elements in the vector.
TEST_F(CollectionTest, ResizeIncreasesCollectionSize)
{
    add_entries(5);

    // Establish the original size before performing the operation.
    ASSERT_EQ(collection->size(), 5U);

    collection->resize(10);

    // Prove that resize() increased the collection to the requested size.
    EXPECT_EQ(collection->size(), 10U);
    EXPECT_FALSE(collection->empty());

    // New integer elements created by resize() should be value-initialized to zero.
    for (std::size_t index = 5; index < collection->size(); ++index)
    {
        EXPECT_EQ(collection->at(index), 0);
    }
}

// Verify that resize() can reduce the number of elements in the vector.
TEST_F(CollectionTest, ResizeDecreasesCollectionSize)
{
    add_entries(10);

    // Establish the original size before reducing the collection.
    ASSERT_EQ(collection->size(), 10U);

    collection->resize(5);

    // Prove that only five elements remain after resizing.
    EXPECT_EQ(collection->size(), 5U);
    EXPECT_FALSE(collection->empty());
}

// Verify that resize(0) removes every element from the vector.
TEST_F(CollectionTest, ResizeDecreasesCollectionToZero)
{
    add_entries(10);

    // Confirm that the vector contains data before resizing it to zero.
    ASSERT_EQ(collection->size(), 10U);
    ASSERT_FALSE(collection->empty());

    collection->resize(0);

    // Prove that no elements remain after the resize operation.
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0U);
}

// Verify that clear() removes every element from the vector.
TEST_F(CollectionTest, ClearErasesEntireCollection)
{
    add_entries(10);

    // Confirm that the vector contains elements before clearing it.
    ASSERT_EQ(collection->size(), 10U);
    ASSERT_FALSE(collection->empty());

    collection->clear();

    // Prove that clear() removed all elements from the vector.
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0U);
}

// Verify that erasing the full iterator range removes every element.
TEST_F(CollectionTest, EraseFullRangeErasesEntireCollection)
{
    add_entries(10);

    // Confirm that the vector contains elements before erasing its range.
    ASSERT_EQ(collection->size(), 10U);
    ASSERT_FALSE(collection->empty());

    collection->erase(collection->begin(), collection->end());

    // Prove that the full-range erase removed every element.
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0U);
}

// Verify that reserve() increases capacity without adding elements.
TEST_F(CollectionTest, ReserveIncreasesCapacityWithoutChangingSize)
{
    const std::size_t originalSize = collection->size();
    const std::size_t originalCapacity = collection->capacity();
    const std::size_t requestedCapacity = originalCapacity + 10U;

    collection->reserve(requestedCapacity);

    // reserve() must provide at least the requested capacity.
    EXPECT_GE(collection->capacity(), requestedCapacity);
    EXPECT_GT(collection->capacity(), originalCapacity);

    // Reserving storage must not create any vector elements.
    EXPECT_EQ(collection->size(), originalSize);
    EXPECT_TRUE(collection->empty());
}

// Negative test: Verify that at() rejects an index outside the valid range.
TEST_F(CollectionTest, AtThrowsOutOfRangeForInvalidIndex)
{
    // An empty vector has no valid index, including index zero.
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0U);

    // The test passes only when at(0) throws the expected exception type.
    EXPECT_THROW(static_cast<void>(collection->at(0)), std::out_of_range);
}

// Original positive test: Verify that push_back() stores the supplied value.
TEST_F(CollectionTest, PushBackStoresValueAtEndOfCollection)
{
    ASSERT_TRUE(collection->empty());

    constexpr int expectedValue = 42;
    collection->push_back(expectedValue);

    // Confirm that one element was added and its value was preserved.
    ASSERT_EQ(collection->size(), 1U);
    EXPECT_EQ(collection->back(), expectedValue);
    EXPECT_EQ(collection->at(0), expectedValue);
}

// Original negative test: Verify that an index equal to size() is invalid.
TEST_F(CollectionTest, AtThrowsOutOfRangeWhenIndexEqualsSize)
{
    add_entries(5);

    // Valid indexes are zero through size() minus one.
    ASSERT_EQ(collection->size(), 5U);
    const std::size_t invalidIndex = collection->size();

    // The boundary index must be rejected with std::out_of_range.
    EXPECT_THROW(
        static_cast<void>(collection->at(invalidIndex)),
        std::out_of_range);
}